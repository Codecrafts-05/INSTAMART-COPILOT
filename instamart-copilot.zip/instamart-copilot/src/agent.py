"""Part D tasks 5-8: tools, ReAct loop, safety limits, checkpoint + resume."""
import json, os, re, sqlite3, sys, time, uuid
from datetime import datetime, timezone
import pandas as pd
sys.path.insert(0, ".")
import mock_llm
from src.rag import retrieve

DB, LEDGER, STATE_DIR = "data/instamart.db", "outputs/refund_ledger.jsonl", "state"
AGENT_SYSTEM = ("You are a refund AGENT for Instamart support. Use the tools get_order, search_policy, calculate_refund, "
                "issue_refund and escalate_to_human. Finish with REFUND:, ESCALATE:, DENIED: or NOT_FOUND:.")

# ------------------------------------------------------------------ tools
def get_order(order_id):
    with sqlite3.connect(DB) as con:
        r = con.execute("select order_id, status, order_amount, delivery_minutes from orders where order_id=?", (order_id,)).fetchone()
    if r is None:
        return {"error": "order not found"}
    dm = None if r[3] is None or r[3] != r[3] else float(r[3])
    return {"order_id": r[0], "status": r[1], "order_amount": float(r[2]), "delivery_minutes": dm}

def search_policy(query):
    return {"results": [{"source": h["source"], "score": round(h["score"], 4), "text": h["text"]} for h in retrieve(query, 3)]}

def calculate_refund(order_amount, delivery_minutes):
    """Completed-order rule: > 45 minutes -> 100% of order_amount, otherwise 0. (Status is checked by the agent flow.)"""
    if delivery_minutes is None or delivery_minutes <= 45:
        return {"refund_inr": 0.0}
    return {"refund_inr": round(float(order_amount), 2)}

def _ledger_append(tool, order_id, refund_inr):
    """Idempotent: an order is never paid or escalated twice by the same tool (guards against replay after a crash)."""
    os.makedirs(os.path.dirname(LEDGER), exist_ok=True)
    if os.path.exists(LEDGER):
        for line in open(LEDGER):
            e = json.loads(line)
            if e["tool"] == tool and e["order_id"] == order_id:
                return {"refund_inr": refund_inr}
    with open(LEDGER, "a") as f:
        f.write(json.dumps({"timestamp": datetime.now(timezone.utc).isoformat(), "tool": tool, "order_id": order_id, "refund_inr": refund_inr}) + "\n")
    return {"refund_inr": refund_inr}

def issue_refund(order_id, refund_inr):
    return _ledger_append("issue_refund", order_id, refund_inr)

def escalate_to_human(order_id, refund_inr):
    return _ledger_append("escalate_to_human", order_id, refund_inr)

def _spec(name, desc, props):
    return {"name": name, "description": desc, "parameters": {"type": "object", "properties": props, "required": list(props)}}

TOOLS_SPEC = [
    _spec("get_order", "Look up an order's status, amount and delivery time in the database.", {"order_id": {"type": "string"}}),
    _spec("search_policy", "Search the policy documents and return the most relevant chunks.", {"query": {"type": "string"}}),
    _spec("calculate_refund", "Compute the refund in INR from the order amount and delivery minutes.",
          {"order_amount": {"type": "number"}, "delivery_minutes": {"type": "number"}}),
    _spec("issue_refund", "Issue an automatic refund of up to INR 1000 and record it in the ledger.",
          {"order_id": {"type": "string"}, "refund_inr": {"type": "number"}}),
    _spec("escalate_to_human", "Send a refund above INR 1000 to a human support lead and record it in the ledger.",
          {"order_id": {"type": "string"}, "refund_inr": {"type": "number"}}),
]
TOOL_MAP = {"get_order": get_order, "search_policy": search_policy, "calculate_refund": calculate_refund,
            "issue_refund": issue_refund, "escalate_to_human": escalate_to_human}

class SimulatedCrash(Exception):
    pass

# ------------------------------------------------------------------ loop
def _checkpoint(st):
    os.makedirs(STATE_DIR, exist_ok=True)
    data = {k: st[k] for k in ("run_id", "scenario_id", "messages", "tokens_used", "step", "tools_executed", "llm_calls", "steps")}
    with open(os.path.join(STATE_DIR, f"{st['run_id']}.json"), "w") as f:
        json.dump(data, f, default=str)

def _result(st, status, final_answer):
    return dict(run_id=st["run_id"], scenario_id=st["scenario_id"], status=status, final_answer=final_answer, steps=st["steps"],
                llm_calls=st["llm_calls"], tokens_used=st["tokens_used"])

def _fallback(st, status, why):
    last = st["steps"][-1]["tool"] if st["steps"] else "none"
    return _result(st, status, f"HANDOFF TO HUMAN: stopped because {why} after {len(st['steps'])} tool step(s); last tool: {last}. Please review this request manually.")

def _loop(st, max_iterations, token_limit, time_limit_seconds, crash_after_tools=None):
    start = time.monotonic()
    while st["llm_calls"] < max_iterations:
        if time.monotonic() - start >= time_limit_seconds:                       # (c) wall-clock limit
            return _fallback(st, "FALLBACK_TIMEOUT", f"the {time_limit_seconds}s time limit was reached")
        resp = mock_llm.chat(st["messages"], TOOLS_SPEC)
        st["llm_calls"] += 1
        st["tokens_used"] += resp.usage.total_tokens
        if st["tokens_used"] > token_limit:                                      # (b) stop before executing the requested tool
            return _fallback(st, "FALLBACK_TOKEN_LIMIT", f"the token limit of {token_limit} was exceeded")
        msg = resp.choices[0].message
        if not msg.tool_calls:
            text = msg.content or ""
            return _result(st, text.split(":")[0].strip(), text)
        st["messages"].append({"role": "assistant", "content": None,
                               "tool_calls": [{"id": t.id, "name": t.name, "arguments": t.arguments} for t in msg.tool_calls]})
        for t in msg.tool_calls:
            obs = TOOL_MAP[t.name](**t.arguments)                                # look the name up and call it
            st["step"] += 1
            st["tools_executed"].append(t.name)
            st["steps"].append({"tool": t.name, "arguments": t.arguments, "observation": obs})
            st["messages"].append({"role": "tool", "tool_call_id": t.id, "name": t.name, "content": json.dumps(obs)})
            _checkpoint(st)
            if crash_after_tools is not None and len(st["tools_executed"]) == crash_after_tools:
                raise SimulatedCrash(f"simulated crash after tool #{crash_after_tools} ({t.name})")
    return _fallback(st, "FALLBACK_MAX_ITERATIONS", f"{max_iterations} model calls passed without a final answer")   # (a)

def run_agent(user_message, scenario_id, max_iterations=6, token_limit=6000, time_limit_seconds=10, crash_after_tools=None, run_id=None):
    st = dict(run_id=run_id or f"{scenario_id}-{uuid.uuid4().hex[:8]}", scenario_id=scenario_id,
              messages=[{"role": "system", "content": AGENT_SYSTEM}, {"role": "user", "content": user_message}],
              tokens_used=0, step=0, tools_executed=[], llm_calls=0, steps=[])
    return _loop(st, max_iterations, token_limit, time_limit_seconds, crash_after_tools)

def resume_agent(run_id, max_iterations=6, token_limit=6000, time_limit_seconds=10):
    with open(os.path.join(STATE_DIR, f"{run_id}.json")) as f:
        st = json.load(f)
    return _loop(st, max_iterations, token_limit, time_limit_seconds)

def refund_amount(res):
    for s in reversed(res["steps"]):
        if s["tool"] in ("issue_refund", "escalate_to_human"):
            return s["observation"]["refund_inr"]
    return 0.0

# ------------------------------------------------------------------ driver
if __name__ == "__main__":
    for p in (LEDGER, "outputs/agent_runs.jsonl", "outputs/agent_demo_runs.jsonl"):
        if os.path.exists(p):
            os.remove(p)
    if os.path.isdir(STATE_DIR):
        for f in os.listdir(STATE_DIR):
            os.remove(os.path.join(STATE_DIR, f))
    sc = pd.read_csv("data/raw/agent_scenarios.csv")
    mock_llm.reset()
    rows = []
    with open("outputs/agent_runs.jsonl", "a") as out:
        for r in sc.itertuples():
            res = run_agent(r.message, r.scenario_id)
            amt = refund_amount(res)
            out.write(json.dumps({k: res[k] for k in ("scenario_id", "status", "final_answer", "llm_calls", "tokens_used", "steps")}) + "\n")
            ok = res["status"].startswith(r.expected_outcome) and abs(amt - r.expected_refund_inr) < 0.01
            rows.append(dict(scenario=r.scenario_id, expected=r.expected_outcome, status=res["status"], refund_inr=amt, expected_refund=r.expected_refund_inr,
                             llm_calls=res["llm_calls"], tokens=res["tokens_used"], match=ok))
    print(pd.DataFrame(rows).to_string(index=False))
    assert all(x["match"] for x in rows)

    s1 = sc.iloc[0]
    demos = []
    d1 = run_agent(s1.message, "S1", token_limit=200)
    d2 = run_agent(s1.message, "S1", time_limit_seconds=0)
    print("\nS1 token_limit=200 ->", d1["status"], "| llm_calls", d1["llm_calls"], "| tokens", d1["tokens_used"], "| steps done", len(d1["steps"]))
    print("S1 time_limit_seconds=0 ->", d2["status"], "| llm_calls", d2["llm_calls"])
    print("fallback summaries:\n ", d1["final_answer"], "\n ", d2["final_answer"])
    try:
        run_agent(s1.message, "S1", run_id="S1-crashdemo", crash_after_tools=2)
        raise AssertionError("crash was not raised")
    except SimulatedCrash as e:
        print("\ncrash:", e)
    d3 = resume_agent("S1-crashdemo")
    print("resume ->", d3["status"], "| refund", refund_amount(d3), "| tools executed across crash+resume:", [s["tool"] for s in d3["steps"]],
          "| model calls:", d3["llm_calls"])
    assert [s["tool"] for s in d3["steps"]] == ["get_order", "search_policy", "calculate_refund", "issue_refund"]
    assert d3["status"] == "REFUND" and abs(refund_amount(d3) - 128.25) < 0.01
    with open("outputs/agent_demo_runs.jsonl", "a") as out:
        for label, d in [("S1_token_limit_200", d1), ("S1_time_limit_0", d2), ("S1_crash_resume", d3)]:
            out.write(json.dumps({"demo": label, "status": d["status"], "final_answer": d["final_answer"], "llm_calls": d["llm_calls"],
                                  "tokens_used": d["tokens_used"], "steps": d["steps"]}) + "\n")
    print("\nledger lines:", sum(1 for _ in open(LEDGER)), "| state files:", len(os.listdir(STATE_DIR)))
