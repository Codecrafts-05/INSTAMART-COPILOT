"""Part C: support-ticket triage with guardrails, redaction, retries, output validation, budget and routing."""
import json, random, re, sys, time
import pandas as pd
sys.path.insert(0, ".")
import mock_llm
from mock_llm import est_tokens, TransientLLMError

MAX_INPUT_TOKENS, BASE_DELAY, MAX_RETRIES = 400, 0.05, 3
CATEGORIES = ["billing", "delivery", "technical", "fraud"]
PATTERNS = [("email", re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[EMAIL]"),
            ("phone", re.compile(r"\b[6-9]\d{9}\b"), "[PHONE]"),
            ("order_id", re.compile(r"ORD-\d{6}"), "[ORDER_ID]")]

ZERO_SHOT = ('You CLASSIFY customer support tickets into exactly one category: billing, delivery, technical or fraud. '
             'Reply with JSON only, in the form {"category": "...", "reason": "..."}.')
FEW_SHOT = ZERO_SHOT + """
EXAMPLES:
Ticket: Someone used my card without permission, this is an unauthorized transaction. -> {"category": "fraud", "reason": "unauthorized use"}
Ticket: I was charged twice and the bill is wrong. -> {"category": "billing", "reason": "double charge"}
Ticket: The app crashes when I open the cart. -> {"category": "technical", "reason": "app crash"}
Ticket: My order is very late and the rider is not answering. -> {"category": "delivery", "reason": "late delivery"}"""
assert "CLASSIFY" in ZERO_SHOT and "EXAMPLES:" not in ZERO_SHOT and "EXAMPLES:" in FEW_SHOT

def redact(text, counts=None):
    for name, pat, ph in PATTERNS:
        text, n = pat.subn(ph, text)
        if counts is not None:
            counts[name] += n
    return text

def call_with_retry(messages, ticket_id, log, waits, errors):
    retry = 0
    while True:
        try:
            return mock_llm.chat(messages)
        except TransientLLMError:
            errors.append(ticket_id)
            if retry >= MAX_RETRIES:
                raise
            wait = BASE_DELAY * 2 ** retry * random.uniform(0.9, 1.15)
            log.append(f"RETRY ticket={ticket_id} retry={retry} wait={wait:.4f}s")
            waits.append((retry, wait))
            time.sleep(wait)
            retry += 1

def validate(content):
    """Return (status, category). Never guesses."""
    try:
        obj = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        words = set(re.findall(r"[a-z]+", (content or "").lower()))
        found = [c for c in CATEGORIES if c in words]
        return ("classified_keyword", found[0]) if len(found) == 1 else ("flagged_invalid_output", "")
    if isinstance(obj, dict) and obj.get("category") in CATEGORIES:
        return "classified_json", obj["category"]
    return "flagged_invalid_output", ""

def run_pipeline(tickets, system_prompt, token_budget=None, seed=42):
    random.seed(seed)
    mock_llm.reset()                                   # immediately before each full run
    rows, log, waits, errors, sent = [], [], [], [], []
    total_tokens = 0
    for t in tickets.itertuples():
        row = dict(ticket_id=t.ticket_id, customer_id=t.customer_id, true_category=t.true_category,
                   status=None, category="", tokens_used=0)
        text = t.text
        if text.strip() == "":
            row["status"] = "skipped_empty"
        elif est_tokens(text) > MAX_INPUT_TOKENS:
            row["status"] = "flagged_long"
        elif token_budget is not None and total_tokens >= token_budget:
            row["status"] = "budget_exhausted"
        else:
            clean = redact(text)
            messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": clean}]
            sent.append(messages)
            resp = call_with_retry(messages, t.ticket_id, log, waits, errors)
            used = resp.usage.total_tokens
            total_tokens += used
            row["tokens_used"] = used
            row["status"], row["category"] = validate(resp.choices[0].message.content)
        rows.append(row)
    return pd.DataFrame(rows), dict(log=log, waits=waits, errors=errors, sent=sent, total_tokens=total_tokens)

def summarise(df, info, label):
    cls = df[df.status.isin(["classified_json", "classified_keyword"])]
    acc = (cls.category == cls.true_category).mean() if len(cls) else float("nan")
    return dict(run=label, classified=len(cls), correct=int((cls.category == cls.true_category).sum()),
                accuracy_pct=round(100 * acc, 1), total_tokens=info["total_tokens"],
                tokens_per_classified=round(info["total_tokens"] / max(len(cls), 1), 1))

if __name__ == "__main__":
    tickets = pd.read_csv("data/raw/tickets.csv", keep_default_na=False)
    print("tickets:", len(tickets), "| empty:", int((tickets.text.str.strip() == "").sum()),
          "| long (>%d est tokens):" % MAX_INPUT_TOKENS, int(tickets.text.map(est_tokens).gt(MAX_INPUT_TOKENS).sum()),
          "| est tokens of a long ticket:", int(tickets.text.map(est_tokens).max()))

    # ---- redaction counts over all 164 tickets + re-scan
    counts = {n: 0 for n, _, _ in PATTERNS}
    red = [redact(t, counts) for t in tickets.text]
    print("\nRedaction substitutions:", counts, "| total:", sum(counts.values()))
    left = sum(len(p.findall(r)) for r in red for _, p, _ in PATTERNS)
    print("PII patterns found when re-applied to redacted texts:", left)
    assert left == 0

    # ---- zero-shot and few-shot full runs (no budget)
    results = {}
    for label, prompt in [("zero-shot", ZERO_SHOT), ("few-shot", FEW_SHOT)]:
        df, info = run_pipeline(tickets, prompt)
        results[label] = (df, info)
        # privacy assertion: nothing but the redacted text reached the model
        for m in info["sent"]:
            assert m[1]["role"] == "user" and m[1]["content"] == redact(m[1]["content"])
            assert not any(p.search(m[1]["content"]) for _, p, _ in PATTERNS)
            assert not any(p.search(m[0]["content"]) for _, p, _ in PATTERNS)
        print(f"\n=== {label} run ===")
        print("status counts:", df.status.value_counts().to_dict())
        print("transient errors:", len(info["errors"]), "| retries logged:", len(info["log"]))
        assert len(info["errors"]) == len(info["log"]) and all(df.status != "permanent_error")
        assert all(0.05 * 2 ** n * 0.9 - 1e-9 <= w <= 0.05 * 2 ** n * 1.15 + 1e-9 for n, w in info["waits"])
        print("retry numbers seen:", sorted({n for n, _ in info["waits"]}), "| wait range: %.4f-%.4fs" % (min(w for _, w in info["waits"]), max(w for _, w in info["waits"])))
        print("model calls with a prompt:", len(info["sent"]), "| system prompt est tokens:", est_tokens(prompt))
        if label == "zero-shot":
            print("first 3 retry log lines:"); [print("  ", l) for l in info["log"][:3]]
    print("\n=== comparison ===")
    comp = pd.DataFrame([summarise(*results[k], k) for k in results])
    print(comp.to_string(index=False))
    zs = results["zero-shot"][0]
    zs = zs[zs.status.isin(["classified_json", "classified_keyword"])]
    print("\nZero-shot confusion table (rows=true, cols=predicted):\n", pd.crosstab(zs.true_category, zs.category).to_string())

    # ---- budget demo (zero-shot)
    budget = 6000
    bdf, binfo = run_pipeline(tickets, ZERO_SHOT, token_budget=budget)
    n_ex = int((bdf.status == "budget_exhausted").sum())
    print(f"\nBudget demo: TOKEN_BUDGET={budget} -> budget_exhausted={n_ex}, tokens spent={binfo['total_tokens']}, status counts={bdf.status.value_counts().to_dict()}")
    assert n_ex >= 1
    seg = pd.read_csv("outputs/customer_segments.csv").set_index("customer_id")
    bdf.assign(tokens_used=bdf.tokens_used)[["ticket_id", "customer_id", "status", "category", "tokens_used"]].to_csv("outputs/triage_budget_demo.csv", index=False)

    # ---- final run + routing
    fdf, finfo = run_pipeline(tickets, FEW_SHOT, token_budget=100000)
    fdf["segment_name"] = fdf.customer_id.map(seg.segment_name).fillna("")
    prem = fdf.customer_id.map(seg.is_premium).fillna(False).astype(bool)
    def route(r, p):
        if r.status in ("skipped_empty", "flagged_long", "flagged_invalid_output", "budget_exhausted"):
            return "human_review", "NORMAL"
        if r.category == "fraud":
            return "security_team", "HIGH"
        if p:
            return "premium_desk", "HIGH"
        return "support_queue", "NORMAL"
    rp = [route(r, p) for r, p in zip(fdf.itertuples(), prem)]
    fdf["route"], fdf["priority"] = [x[0] for x in rp], [x[1] for x in rp]
    fdf[["ticket_id", "customer_id", "status", "category", "segment_name", "priority", "route", "tokens_used"]].to_csv("outputs/triage_results.csv", index=False)
    print("\nFinal run (few-shot, budget 100000): rows", len(fdf), "| status:", fdf.status.value_counts().to_dict())
    print("routes:", fdf.route.value_counts().to_dict(), "| priority:", fdf.priority.value_counts().to_dict())
    print("tickets with no segment row (treated as non-premium):", int((fdf.segment_name == "").sum()))
    print("rule-validated (classified_json + classified_keyword):", int(fdf.status.isin(['classified_json','classified_keyword']).sum()),
          "| sent to human review:", int((fdf.route == "human_review").sum()))
