"""Validate Part A reference checkpoints. Prints ALL CHECKPOINTS PASSED when everything holds."""
import sqlite3
import pandas as pd

raw_o = pd.read_csv("data/raw/orders.csv")
raw_c = pd.read_csv("data/raw/customers.csv")
c = pd.read_csv("data/clean/customers.csv")
o = pd.read_csv("data/clean/orders.csv")
con = sqlite3.connect("data/instamart.db")
comp = o[o.status == "completed"]

checks = {
    "raw order rows == 13084": len(raw_o) == 13084,
    "exact duplicates == 119": raw_o.duplicated().sum() == 119,
    "pending rows == 656": (raw_o.status == "pending").sum() == 656,
    "distinct order_id == 12309": raw_o.order_id.nunique() == 12309,
    "non-numeric amounts == 120": pd.to_numeric(raw_o.order_amount, errors="coerce").isna().sum() == 120,
    "raw blank delivery == 2541": raw_o.delivery_minutes.isna().sum() == 2541,
    "raw negative delivery == 106": (raw_o.delivery_minutes < 0).sum() == 106,
    "raw blank age == 61": raw_c.age.isna().sum() == 61,
    "raw city spellings == 24": raw_c.city.nunique() == 24,
    "raw gender spellings == 10": raw_c.gender.dropna().nunique() == 10,
    "clean cities == 6": c.city.nunique() == 6,
    "city counts": c.city.value_counts().to_dict() == {"Pune": 227, "Delhi": 210, "Bengaluru": 197, "Chennai": 191, "Hyderabad": 191, "Mumbai": 184},
    "gender counts": c.gender.value_counts().to_dict() == {"female": 610, "male": 560, "unknown": 30},
    "ages complete and within 18-60": c.age.isna().sum() == 0 and c.age.between(18, 60).all(),
    "clean order rows == 12309": len(o) == 12309,
    "completed == 11110, cancelled == 1199": (o.status == "completed").sum() == 11110 and (o.status == "cancelled").sum() == 1199,
    "no pending rows": (o.status == "pending").sum() == 0,
    "no missing order_amount": o.order_amount.isna().sum() == 0,
    "delivery missing: 0 completed / 1199 cancelled": comp.delivery_minutes.isna().sum() == 0 and o[o.status == "cancelled"].delivery_minutes.isna().sum() == 1199,
    "completed revenue == 2998668.80": round(comp.order_amount.sum(), 2) == 2998668.80,
    "db tables exist": {r[0] for r in con.execute("select name from sqlite_master where type='table'")} >= {"customers", "products", "orders"},
    "db orders rows == 12309": con.execute("select count(*) from orders").fetchone()[0] == 12309,
}
failed = [k for k, v in checks.items() if not v]
for k, v in checks.items():
    print(("PASS  " if v else "FAIL  ") + k)
assert not failed, f"failed: {failed}"
print("ALL CHECKPOINTS PASSED")
