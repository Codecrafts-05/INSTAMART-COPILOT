"""Run the seven queries of sql/queries.sql and report the stated results."""
import re, sqlite3
import pandas as pd

sql = open("sql/queries.sql").read()
queries = [q.strip() for q in re.split(r"^-- Q\d+:.*$", sql, flags=re.M) if q.strip()]
assert len(queries) == 7
con = sqlite3.connect("data/instamart.db")
R = [pd.read_sql_query(q, con) for q in queries]

print("Q1 customers:", len(R[0]))
print("Q2 rows:", len(R[1]), "| total revenue: INR %.2f" % R[1].revenue.sum())
print("Q2 largest cell:", R[1].iloc[0].to_dict())
print("Q3 products above average price:", len(R[2]))
print("Q4 customers without completed order:", len(R[3]))
print("Q5 customers above average:", len(R[4]), "| average INR", R[4].avg_total.iloc[0])
q6 = R[5]
print("Q6 top customer per city:")
print(q6[q6.row_num == 1][["city", "customer_id", "total_spend"]].to_string(index=False))
print("Q6 rows where RANK() != ROW_NUMBER():", int((q6.rnk != q6.row_num).sum()))
print("Q7 daily rows:", len(R[6]), "| last cumulative: INR %.2f" % R[6].cumulative_revenue.iloc[-1])
