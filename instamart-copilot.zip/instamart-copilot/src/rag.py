"""Part D tasks 1-4: chunking, TF-IDF retrieval, grounded answering, evaluation. Reused by the refund agent."""
import glob, os, sys
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
sys.path.insert(0, ".")
import mock_llm

POLICY_DIR = os.path.join("data", "policies")

def chunk_words(words, size=40, overlap=10):
    """First chunk = words 0..size-1, next starts size-overlap later; stop after the first chunk reaching the last word."""
    step, chunks, start = size - overlap, [], 0
    while True:
        chunks.append(" ".join(words[start:start + size]))
        if start + size >= len(words):
            break
        start += step
    return chunks

def build_chunks(size=40, overlap=10, policy_dir=POLICY_DIR):
    out = []
    for path in sorted(glob.glob(os.path.join(policy_dir, "*.txt"))):
        words = open(path, encoding="utf-8").read().split()
        out += [{"source": os.path.basename(path), "text": t} for t in chunk_words(words, size, overlap)]
    return out

class Retriever:
    def __init__(self, size=40, overlap=10):
        self.chunks = build_chunks(size, overlap)
        self.vec = TfidfVectorizer()
        self.matrix = self.vec.fit_transform([c["text"] for c in self.chunks])
    def retrieve(self, query, k=3):
        sims = cosine_similarity(self.vec.transform([query]), self.matrix)[0]
        order = sims.argsort()[::-1][:k]
        return [{"source": self.chunks[i]["source"], "score": float(sims[i]), "text": self.chunks[i]["text"]} for i in order]

_default = None
def default_retriever():
    global _default
    if _default is None:
        _default = Retriever()
    return _default

def retrieve(query, k=3):
    return default_retriever().retrieve(query, k)

POLICY_SYSTEM = ("You are a POLICY ASSISTANT for Instamart support. Answer only from the supplied context. "
                 "If the answer is not in the context, say that you could not find the information.")

def answer(question, retriever=None):
    hits = (retriever or default_retriever()).retrieve(question, 3)
    ctx = "\n".join(f"[{h['source']}]\n{h['text']}" for h in hits)
    messages = [{"role": "system", "content": POLICY_SYSTEM},
                {"role": "user", "content": f"CONTEXT:\n{ctx}\nQUESTION:\n{question}"}]
    resp = mock_llm.chat(messages)
    return resp.choices[0].message.content, [h["source"] for h in hits]

def evaluate(retriever):
    qa = pd.read_csv("data/raw/policy_eval.csv", keep_default_na=False)
    ans_q = qa[qa.expected_doc != "NONE"]; none_q = qa[qa.expected_doc == "NONE"]
    doc_hits = fact_hits = fallback = 0
    failures = []
    for r in ans_q.itertuples():
        text, srcs = answer(r.question, retriever)
        d, f = r.expected_doc in srcs, r.expected_fact in text
        doc_hits += d; fact_hits += f
        if not (d and f):
            failures.append((r.question, d, f, text))
    for r in none_q.itertuples():
        text, _ = answer(r.question, retriever)
        fallback += text.startswith("I could not find")
    return dict(answerable=len(ans_q), doc_hits=int(doc_hits), fact_hits=int(fact_hits), unanswerable=len(none_q), fallback=int(fallback)), failures

if __name__ == "__main__":
    ch = build_chunks()
    print("chunks total:", len(ch), pd.Series([c["source"] for c in ch]).value_counts().to_dict())
    print("\nretrieve('refund policy late delivery'):")
    for h in retrieve("refund policy late delivery"):
        print("  %s  %.3f  %s..." % (h["source"], h["score"], h["text"][:60]))
    for label, (size, ov) in {"overlap 10 (40-word chunks)": (40, 10), "overlap 0 (40-word chunks)": (40, 0)}.items():
        rt = Retriever(size, ov)
        res, fails = evaluate(rt)
        print(f"\n=== {label}: {len(rt.chunks)} chunks ===")
        print(f"expected_doc in top-3: {res['doc_hits']}/{res['answerable']} | expected_fact in answer: {res['fact_hits']}/{res['answerable']} | fallback on unanswerable: {res['fallback']}/{res['unanswerable']}")
        for q, d, f, t in fails:
            print(f"  FAIL: {q!r} doc_ok={d} fact_ok={f}\n        answer: {t}")
