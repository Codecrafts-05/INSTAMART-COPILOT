"""Part A: pandas cross-check of Q2 and exploratory statistics of completed order_amount."""
import sqlite3
import numpy as np
import pandas as pd

con = sqlite3.connect("data/instamart.db")
o = pd.read_sql_query("select * from orders", con)
c = pd.read_sql_query("select * from customers", con)
p = pd.read_sql_query("select * from products", con)
comp = o[o.status == "completed"].merge(c[["customer_id", "city"]], on="customer_id").merge(p[["product_id", "category"]], on="product_id")

pt = pd.pivot_table(comp, values="order_amount", index="city", columns="category", aggfunc="sum", margins=True)
sql_total = pd.read_sql_query(open("sql/queries.sql").read().split("-- Q3")[0].split("-- Q2:")[1].split("\n", 1)[1], con).revenue.sum()
print("pivot grand total: INR %.2f | SQL Q2 total: INR %.2f | equal: %s" % (pt.loc["All", "All"], sql_total, abs(pt.loc["All", "All"] - sql_total) < 0.01))
print("largest non-margin cell:", pt.drop(index="All", columns="All").stack().idxmax(), round(pt.drop(index="All", columns="All").stack().max(), 2))

agg = comp.groupby("city").agg(total=("order_amount", "sum"), mean=("order_amount", "mean"), count=("order_amount", "count")).round(2)
print("\nPer-city aggregates:\n", agg.to_string())

x = comp.order_amount
q1, q3 = x.quantile(.25), x.quantile(.75); iqr = q3 - q1
lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
print("\nmean %.2f median %.2f skew %.2f" % (x.mean(), x.median(), x.skew()))
print("Q1 %.2f Q3 %.2f IQR %.2f | fences lower %.2f upper %.2f" % (q1, q3, iqr, lo, hi))
print("outliers below %d, above %d" % ((x < lo).sum(), (x > hi).sum()))
corr = comp[["order_amount", "discount_pct", "quantity", "delivery_minutes"]].corr()
print("\nCorrelation matrix:\n", corr.round(3).to_string())
pairs = corr.where(np.triu(np.ones(corr.shape, bool), 1)).stack()
print("largest |corr| pair:", pairs.abs().idxmax(), round(pairs[pairs.abs().idxmax()], 3))
