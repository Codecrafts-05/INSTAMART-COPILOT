"""Part B tasks 4-8: lapse definition, leakage-free preprocessing, tuning, balancing, interpretation, persistence."""
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

CUTOFF, END = pd.Timestamp("2025-09-01"), pd.Timestamp("2025-10-01")

o = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"])
cust = pd.read_csv("data/clean/customers.csv", parse_dates=["signup_date"])
prod = pd.read_csv("data/clean/products.csv")

# ---------- task 4: cohort, label, features (ONLY orders dated before the cutoff feed the features)
pre = o[o.order_ts < CUTOFF].merge(prod[["product_id", "category"]], on="product_id")
pre_c = pre[pre.status == "completed"]
cohort_ids = pre_c.customer_id.unique()
sept = o[(o.order_ts >= CUTOFF) & (o.order_ts < END) & (o.status == "completed")]
active_sept = set(sept.customer_id)

g = pre_c.groupby("customer_id")
feat = pd.DataFrame({
    "recency": (CUTOFF - g.order_ts.max()).dt.days,
    "frequency": g.order_id.nunique(),
    "monetary": g.order_amount.sum(),
    "avg_discount": g.discount_pct.mean(),
    "avg_delivery": g.delivery_minutes.mean(),
    "fav_category": g.category.agg(lambda s: sorted(s.value_counts().loc[lambda v: v == v.max()].index)[0]),
})
final_pre = pre[pre.status.isin(["completed", "cancelled"])]
feat["cancel_rate"] = final_pre.groupby("customer_id").status.apply(lambda s: (s == "cancelled").mean()).reindex(feat.index).fillna(0)
feat = feat.reset_index().merge(cust[["customer_id", "city", "age", "gender", "signup_date"]], on="customer_id")
feat["tenure_days"] = (CUTOFF - feat.signup_date).dt.days
feat = feat.drop(columns="signup_date")
feat["lapsed"] = (~feat.customer_id.isin(active_sept)).astype(int)
assert pre.order_ts.max() < CUTOFF

NUM = ["recency", "frequency", "monetary", "avg_discount", "cancel_rate", "avg_delivery", "age", "tenure_days"]
CAT = ["city", "gender", "fav_category"]
X, y, ids = feat[NUM + CAT], feat["lapsed"], feat["customer_id"]
print("cohort size:", len(feat), "| lapsed:", int(y.sum()), "(%.2f%%)" % (100 * y.mean()))
X_tr, X_te, y_tr, y_te, id_tr, id_te = train_test_split(X, y, ids, test_size=0.2, stratify=y, random_state=42)
print("train/test:", len(X_tr), len(X_te), "| train lapsed", int(y_tr.sum()), "| test lapsed", int(y_te.sum()))
base = np.zeros(len(y_te), dtype=int)
print("baseline accuracy %.3f  lapsed-F1 %.3f" % (accuracy_score(y_te, base), f1_score(y_te, base, zero_division=0)))

# ---------- task 5: preprocessing, fitted on training rows only (inside the Pipeline)
def prep():
    return ColumnTransformer([("num", StandardScaler(), NUM),
                              ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), CAT)])
print("missing values in feature columns:", int(X.isna().sum().sum()))
assert X.isna().sum().sum() == 0
chk = prep().fit(X_tr)
fi = NUM.index("frequency")
print("scaler learned mean of frequency (train only): %.4f | full-cohort mean: %.4f" % (chk.named_transformers_["num"].mean_[fi], X["frequency"].mean()))

# ---------- task 6: tuning and evaluation
def metrics(m, Xt, yt):
    p = m.predict(Xt)
    return dict(cm=confusion_matrix(yt, p), precision=precision_score(yt, p, zero_division=0),
                recall=recall_score(yt, p, zero_division=0), f1=f1_score(yt, p, zero_division=0))

lr_gs = GridSearchCV(Pipeline([("prep", prep()), ("clf", LogisticRegression(max_iter=1000))]),
                     {"clf__C": [0.01, 0.1, 1, 10, 100]}, cv=5, scoring="f1").fit(X_tr, y_tr)
rf_gs = GridSearchCV(Pipeline([("prep", prep()), ("clf", RandomForestClassifier(n_estimators=100, random_state=42))]),
                     {"clf__max_depth": [3, 5, 8], "clf__min_samples_leaf": [5, 10, 20]}, cv=5, scoring="f1").fit(X_tr, y_tr)
print("\nLR best params", lr_gs.best_params_, "CV F1 %.3f" % lr_gs.best_score_)
print("RF best params", rf_gs.best_params_, "CV F1 %.3f" % rf_gs.best_score_)
res = {"LogisticRegression": metrics(lr_gs.best_estimator_, X_te, y_te), "RandomForest": metrics(rf_gs.best_estimator_, X_te, y_te)}
for n, m in res.items():
    print(f"{n}: confusion [[TN FP],[FN TP]] = {m['cm'].tolist()} precision {m['precision']:.3f} recall {m['recall']:.3f} F1 {m['f1']:.3f}")

best_name = max(res, key=lambda k: res[k]["f1"])
best_model = {"LogisticRegression": lr_gs, "RandomForest": rf_gs}[best_name].best_estimator_
print("selected model:", best_name, "| test F1 %.3f" % res[best_name]["f1"])
assert res[best_name]["f1"] >= 0.55

# ---------- task 7: over-sample training rows only
rng_idx = np.random.RandomState(42)
tr = X_tr.assign(lapsed=y_tr.values).reset_index(drop=True)
n_min, n_maj = int(tr.lapsed.sum()), int((tr.lapsed == 0).sum())
extra = tr[tr.lapsed == 1].sample(n=n_maj - n_min, replace=True, random_state=42)
bal = pd.concat([tr, extra], ignore_index=True)
print("\nbalanced training counts:", bal.lapsed.value_counts().to_dict(), "(added %d duplicates)" % len(extra))
lr_best = Pipeline([("prep", prep()), ("clf", LogisticRegression(max_iter=1000, C=lr_gs.best_params_["clf__C"]))])
lr_bal = lr_best.fit(bal[NUM + CAT], bal.lapsed)
m_unbal, m_bal = res["LogisticRegression"], metrics(lr_bal, X_te, y_te)
for n, m in [("LR un-balanced", m_unbal), ("LR balanced", m_bal)]:
    print(f"{n}: precision {m['precision']:.3f} recall {m['recall']:.3f} F1 {m['f1']:.3f} confusion {m['cm'].tolist()}")

# ---------- task 8: interpretation, persistence, retention list
rf_pipe = rf_gs.best_estimator_
names = rf_pipe.named_steps["prep"].get_feature_names_out()
imp = pd.Series(rf_pipe.named_steps["clf"].feature_importances_, index=names).sort_values(ascending=False)
print("\nTop-5 RF importances:\n", imp.head(5).round(4).to_string())
lr_pipe = lr_gs.best_estimator_
coef = pd.Series(lr_pipe.named_steps["clf"].coef_[0], index=lr_pipe.named_steps["prep"].get_feature_names_out())
print("LR coefficients (standardised numerics):\n", coef.loc[["num__recency", "num__frequency", "num__monetary", "num__avg_discount", "num__cancel_rate"]].round(3).to_string())

joblib.dump(best_model, "outputs/lapse_model.joblib")
re = joblib.load("outputs/lapse_model.joblib")
same = bool((re.predict(X_te) == best_model.predict(X_te)).all() and np.allclose(re.predict_proba(X_te), best_model.predict_proba(X_te)))
print("\nreloaded model reproduces test predictions exactly:", same)
assert same

seg = pd.read_csv("outputs/customer_segments.csv")
premium_ids = set(seg.loc[seg.is_premium, "customer_id"])
out = pd.DataFrame({"customer_id": id_te.values, "lapse_probability": best_model.predict_proba(X_te)[:, 1], "actually_lapsed": y_te.values})
out = out[out.customer_id.isin(premium_ids)].sort_values("lapse_probability", ascending=False).head(10)
out["lapse_probability"] = out.lapse_probability.round(4)
out.to_csv("outputs/retention_list.csv", index=False)
print("premium customers in test set:", int(id_te.isin(premium_ids).sum()), "| retention list rows:", len(out),
      "| truly lapsed:", int(out.actually_lapsed.sum()))
print(out.to_string(index=False))
