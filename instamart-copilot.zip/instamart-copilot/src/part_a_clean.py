"""Part A: audit raw exports, clean them with documented rules, store CSV + SQLite."""
import os, sqlite3
import numpy as np
import pandas as pd

RAW, CLEAN, DB = "data/raw", "data/clean", "data/instamart.db"
os.makedirs(CLEAN, exist_ok=True)

cust = pd.read_csv(f"{RAW}/customers.csv")
prod = pd.read_csv(f"{RAW}/products.csv")
orders = pd.read_csv(f"{RAW}/orders.csv")

# ------------------------------------------------------------------ audit
print("=== AUDIT: shape, dtypes, missing per column ===")
for name, df in [("customers", cust), ("products", prod), ("orders", orders)]:
    print(f"\n[{name}] shape={df.shape}")
    t = pd.DataFrame({"dtype": df.dtypes.astype(str), "missing": df.isna().sum(),
                      "missing_pct": (df.isna().mean() * 100).round(2)})
    print(t.to_string())

amt_num = pd.to_numeric(orders["order_amount"], errors="coerce")
age_num = pd.to_numeric(cust["age"], errors="coerce")
audit = {
    "raw orders rows": len(orders),
    "exact duplicate rows": int(orders.duplicated().sum()),
    "rows with status pending": int((orders["status"] == "pending").sum()),
    "distinct order_id": int(orders["order_id"].nunique()),
    "non-numeric order_amount": int(amt_num.isna().sum()),  # includes "N/A", which pandas reads as NaN
    "negative delivery_minutes": int((orders["delivery_minutes"] < 0).sum()),
    "blank delivery_minutes": int(orders["delivery_minutes"].isna().sum()),
    "blank age": int(cust["age"].isna().sum()),
    "age outside 10-100": int(((age_num < 10) | (age_num > 100)).sum()),
    "distinct raw city spellings": int(cust["city"].nunique()),
    "distinct non-blank raw gender spellings": int(cust["gender"].dropna().nunique()),
    "blank gender": int(cust["gender"].isna().sum()),
}
print("\n=== AUDIT FIGURES ===")
for k, v in audit.items():
    print(f"{k}: {v}")

# ------------------------------------------------------------------ clean customers
print("\n=== CLEAN CUSTOMERS ===")
c = cust.copy()
before = c["city"].copy()
c["city"] = c["city"].str.strip().str.title()
print("city values changed by standardisation:", int((before != c["city"]).sum()))
gmap = {"male": "male", "m": "male", "female": "female", "f": "female"}
gl = c["gender"].fillna("").str.strip().str.lower()
c["gender"] = gl.map(gmap).fillna("unknown")
c["age"] = pd.to_numeric(c["age"], errors="coerce")
bad = (c["age"] < 10) | (c["age"] > 100)
print("ages outside 10-100 set to missing:", int(bad.sum()))
c.loc[bad, "age"] = np.nan
n_missing = int(c["age"].isna().sum())
c["age"] = c["age"].fillna(c.groupby("city")["age"].transform("median"))
print("missing ages (blank + impossible) filled with city median:", n_missing)
c["signup_date"] = pd.to_datetime(c["signup_date"])
print(c["city"].value_counts().to_string())
print(c["gender"].value_counts().to_string())
print("missing ages:", int(c["age"].isna().sum()), "age range:", c["age"].min(), c["age"].max())

# ------------------------------------------------------------------ clean orders
print("\n=== CLEAN ORDERS ===")
o = orders.copy()
o["order_ts"] = pd.to_datetime(o["order_ts"])                       # rule 1
n0 = len(o)
o = o.drop_duplicates()                                              # rule 2
print(f"rule 2 exact duplicates removed: {n0 - len(o)}")
n1 = len(o)
o = o.sort_values(["order_id", "order_ts"]).drop_duplicates("order_id", keep="last")   # rule 3
print(f"rule 3 earlier records of repeated order_id removed: {n1 - len(o)}")
o = o.merge(prod[["product_id", "category", "price_inr"]], on="product_id", how="left")
o["order_amount"] = pd.to_numeric(o["order_amount"], errors="coerce")  # rule 4
miss = o["order_amount"].isna()
fill = (o["price_inr"] * o["quantity"] * (1 - o["discount_pct"] / 100)).round(2)
o.loc[miss, "order_amount"] = fill[miss]
print(f"rule 4 unparseable amounts rebuilt from product price: {int(miss.sum())}")
neg = o["delivery_minutes"] < 0                                      # rule 5
o.loc[neg, "delivery_minutes"] = np.nan
print(f"rule 5a negative delivery_minutes set to missing: {int(neg.sum())}")
comp = o["status"] == "completed"
med = o[comp].groupby("category")["delivery_minutes"].transform("median")
fillmask = comp & o["delivery_minutes"].isna()
o.loc[fillmask, "delivery_minutes"] = med[fillmask]
print(f"rule 5b completed orders with delivery_minutes filled by category median: {int(fillmask.sum())}")
o = o.drop(columns=["category", "price_inr"]).sort_values("order_id").reset_index(drop=True)
print("rows:", len(o), "| status counts:", o["status"].value_counts().to_dict())
print("missing order_amount:", int(o["order_amount"].isna().sum()))
print("missing delivery completed:", int(o.loc[o.status == 'completed', 'delivery_minutes'].isna().sum()),
      "| cancelled:", int(o.loc[o.status == 'cancelled', 'delivery_minutes'].isna().sum()))
print("sum completed order_amount: INR %.2f" % o.loc[o.status == "completed", "order_amount"].sum())

# ------------------------------------------------------------------ store
c_out, o_out = c.copy(), o.copy()
c_out["signup_date"] = c_out["signup_date"].dt.strftime("%Y-%m-%d")
o_out["order_ts"] = o_out["order_ts"].dt.strftime("%Y-%m-%d %H:%M:%S")
c_out.to_csv(f"{CLEAN}/customers.csv", index=False)
prod.to_csv(f"{CLEAN}/products.csv", index=False)
o_out.to_csv(f"{CLEAN}/orders.csv", index=False)
if os.path.exists(DB):
    os.remove(DB)
with sqlite3.connect(DB) as con:
    c_out.to_sql("customers", con, index=False)
    prod.to_sql("products", con, index=False)
    o_out.to_sql("orders", con, index=False)
print("\nwrote data/clean/*.csv and", DB)
