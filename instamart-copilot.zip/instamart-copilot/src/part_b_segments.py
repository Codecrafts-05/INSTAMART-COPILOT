"""Part B tasks 1-3: RFM table, K-means selection, segment profile, PCA, outputs/customer_segments.csv."""
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

SNAPSHOT = pd.Timestamp("2025-10-01 00:00:00")
FINAL_K = 4

o = pd.read_csv("data/clean/orders.csv", parse_dates=["order_ts"])
comp = o[o.status == "completed"]
rfm = comp.groupby("customer_id").agg(last_ts=("order_ts", "max"), frequency=("order_id", "nunique"),
                                      monetary=("order_amount", "sum")).reset_index()
rfm["recency"] = (SNAPSHOT - rfm["last_ts"]).dt.days
rfm = rfm[["customer_id", "recency", "frequency", "monetary"]]
print("RFM customers:", len(rfm))
print("recency median %d min %d max %d" % (rfm.recency.median(), rfm.recency.min(), rfm.recency.max()))
print("frequency mean %.2f max %d" % (rfm.frequency.mean(), rfm.frequency.max()))
print("monetary mean %.2f max %.2f" % (rfm.monetary.mean(), rfm.monetary.max()))

X = StandardScaler().fit_transform(rfm[["recency", "frequency", "monetary"]])
print("\nK | inertia | silhouette")
for k in range(2, 9):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    print(f"{k} | {km.inertia_:.1f} | {silhouette_score(X, km.labels_):.3f}")

km = KMeans(n_clusters=FINAL_K, n_init=10, random_state=42).fit(X)
rfm["segment_id"] = km.labels_
prof = rfm.groupby("segment_id").agg(size=("customer_id", "count"), mean_recency=("recency", "mean"),
                                     mean_frequency=("frequency", "mean"), mean_monetary=("monetary", "mean")).round(2)
print("\nSegment profile (K=%d):\n%s" % (FINAL_K, prof.to_string()))

# Business names assigned from the profile itself (cluster numbers are only labels with no ordering)
premium_id = prof["mean_monetary"].idxmax()
rest = prof.drop(index=premium_id)
loyal_id = rest["mean_frequency"].idxmax()
rest = rest.drop(index=loyal_id)
at_risk_id = rest["mean_recency"].idxmax()
names = {premium_id: "Premium Big Spenders", loyal_id: "Loyal Regulars", at_risk_id: "Lapsing / At-Risk"}
for sid in prof.index:
    names.setdefault(sid, "Occasional Shoppers")
rfm["segment_name"] = rfm["segment_id"].map(names)
rfm["is_premium"] = rfm["segment_id"] == premium_id
print("\nSegment names:", {int(k): v for k, v in names.items()}, "| premium segment id:", int(premium_id))
print(rfm.groupby("segment_name").agg(size=("customer_id", "count"), recency=("recency", "mean"),
      frequency=("frequency", "mean"), monetary=("monetary", "mean"), premium=("is_premium", "first")).round(2).to_string())

pca = PCA(n_components=2).fit(X)
print("\nPCA explained_variance_ratio_:", pca.explained_variance_ratio_.round(3), "total %.3f" % pca.explained_variance_ratio_.sum())

rfm[["customer_id", "recency", "frequency", "monetary", "segment_id", "segment_name", "is_premium"]].to_csv(
    "outputs/customer_segments.csv", index=False)
print("wrote outputs/customer_segments.csv rows:", len(rfm))
